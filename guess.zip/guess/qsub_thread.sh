#!/bin/sh
#PBS -N qsub_thread
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=1:ppn=8

# 取本次任务分配到的计算节点
NODE=$(cat $PBS_NODEFILE | head -n 1)

WORKDIR=/home/${USER}/guess
RUNDIR=/home/${USER}/guess_run

echo "PBS job id: $PBS_JOBID"
echo "Run node: $NODE"
echo "Work dir on master: $WORKDIR"
echo "Run dir on compute node: $RUNDIR"
echo "Start time:"
date

# 在计算节点上准备运行目录
ssh $NODE "rm -rf $RUNDIR && mkdir -p $RUNDIR"

# 把可执行文件和必要文件复制到计算节点
scp master_ubss1:$WORKDIR/main $NODE:$RUNDIR/ 1>&2
scp -r master_ubss1:$WORKDIR/files $NODE:$RUNDIR/ 1>&2

# 运行单进程多线程程序
# OpenMP 版本会读取 OMP_NUM_THREADS
# pthread 版本主要由编译时 -DGEN_THREADS 控制
ssh $NODE "cd $RUNDIR && export OMP_NUM_THREADS=8 && ./main"

# 如果程序会修改 files 文件夹，则复制回主节点
scp -r $NODE:$RUNDIR/files/ master_ubss1:$WORKDIR/ 2>&1

echo "End time:"
date