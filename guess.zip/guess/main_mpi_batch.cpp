#include "PCFG.h"
#include "md5.h"
#include <mpi.h>
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

#ifndef GENERATE_LIMIT
#define GENERATE_LIMIT 10000000
#endif

#ifndef USE_SIMD_HASH
#define USE_SIMD_HASH 1
#endif

#ifndef GEN_THREADS
#define GEN_THREADS 4
#endif

#ifndef BATCH_SIZE
#define BATCH_SIZE 64
#endif

static bool CheckMD5Correctness(int rank)
{
    if (rank == 0)
    {
        cout << "Testing MD5Hash correctness..." << endl;
    }

    string test_pws[8] = {"123456", "password", "12345678", "qwerty", "123456789", "12345", "1234", "111111"};
    string test_hashes[8] = {
        "e10adc3949ba59abbe56e057f20f883e",
        "5f4dcc3b5aa765d61d8327deb882cf99",
        "25d55ad283aa400af464c76d713c07ad",
        "d8578edf8458ce06fbc5bb76a58c5ca4",
        "25f9e794323b453885f5181f1b624d0b",
        "827ccb0eea8a706c4c34a16891f84e7b",
        "81dc9bdb52d04dc20036dbd8313ed055",
        "96e79218965eb72c92a549dd5a330112"
    };

    for (int i = 0; i < 8; i++)
    {
        bit32 state[4];
        MD5Hash(test_pws[i], state);

        stringstream ss;
        for (int j = 0; j < 4; j++)
        {
            ss << setw(8) << setfill('0') << hex << state[j];
        }

        if (ss.str() != test_hashes[i])
        {
            if (rank == 0)
            {
                cout << "MD5Hash test failed for " << test_pws[i] << "!" << endl;
                cout << "Expected: " << test_hashes[i] << "\nGot:      " << ss.str() << endl;
            }
            return false;
        }
    }

    if (rank == 0)
    {
        cout << "MD5Hash test passed!" << endl;
    }

    return true;
}

static segment *FindSegmentInModel(model &m, const segment &seg)
{
    int id = -1;
    if (seg.type == 1) id = m.FindLetter(seg);
    if (seg.type == 2) id = m.FindDigit(seg);
    if (seg.type == 3) id = m.FindSymbol(seg);

    if (id < 0) return nullptr;
    if (seg.type == 1) return &m.letters[id];
    if (seg.type == 2) return &m.digits[id];
    if (seg.type == 3) return &m.symbols[id];
    return nullptr;
}

static segment *PrepareGenerateTask(model &m, const PT &pt, string &prefix)
{
    prefix.clear();
    if (pt.content.empty()) return nullptr;

    if (pt.content.size() == 1)
    {
        return FindSegmentInModel(m, pt.content[0]);
    }

    int seg_idx = 0;
    for (int idx : pt.curr_indices)
    {
        if (seg_idx >= (int)pt.content.size() - 1) break;

        segment *seg = FindSegmentInModel(m, pt.content[seg_idx]);
        if (seg != nullptr)
        {
            prefix += seg->ordered_values[idx];
        }
        seg_idx++;
    }

    int last = (int)pt.content.size() - 1;
    return FindSegmentInModel(m, pt.content[last]);
}

static int CountPTCandidates(PriorityQueue &q, const PT &pt)
{
    string prefix;
    segment *a = PrepareGenerateTask(q.m, pt, prefix);
    if (a == nullptr) return 0;
    return (int)a->ordered_values.size();
}

static int GeneratePTLocalOpenMP(PriorityQueue &q, PT pt)
{
    q.CalProb(pt);

    string prefix;
    segment *a = PrepareGenerateTask(q.m, pt, prefix);
    if (a == nullptr) return 0;

    int total = (int)a->ordered_values.size();
    if (total <= 0) return 0;

    q.EnsureLocalBuckets(GEN_THREADS);

    for (int t = 0; t < GEN_THREADS; t++)
    {
        int start = t * total / GEN_THREADS;
        int end = (t + 1) * total / GEN_THREADS;
        q.local_guesses[t].reserve(q.local_guesses[t].size() + (end - start));
    }

#ifdef _OPENMP
#pragma omp parallel num_threads(GEN_THREADS)
#endif
    {
#ifdef _OPENMP
        int tid = omp_get_thread_num();
        int nth = omp_get_num_threads();
#else
        int tid = 0;
        int nth = 1;
#endif
        int start = tid * total / nth;
        int end = (tid + 1) * total / nth;

        vector<string> &local = q.local_guesses[tid];
        for (int i = start; i < end; i++)
        {
            local.emplace_back(prefix + a->ordered_values[i]);
        }
    }

    q.total_guesses += total;
    return total;
}

static void InsertPTByProb(PriorityQueue &q, const PT &pt)
{
    if (q.priority.empty())
    {
        q.priority.emplace_back(pt);
        return;
    }

    for (auto iter = q.priority.begin(); iter != q.priority.end(); iter++)
    {
        if (pt.prob > iter->prob)
        {
            q.priority.emplace(iter, pt);
            return;
        }
    }

    q.priority.emplace_back(pt);
}

static void AdvanceBatchQueue(PriorityQueue &q, const vector<PT> &batch_pts)
{
    int actual_batch_size = (int)batch_pts.size();
    q.priority.erase(q.priority.begin(), q.priority.begin() + actual_batch_size);

    for (PT pt_in_batch : batch_pts)
    {
        vector<PT> new_pts = pt_in_batch.NewPTs();
        for (PT pt : new_pts)
        {
            q.CalProb(pt);
            InsertPTByProb(q, pt);
        }
    }
}

static void HashVector(const vector<string> &v)
{
    if (v.empty()) return;

#if USE_SIMD_HASH
    MD5HashBatchSIMD(v, nullptr);
#else
    bit32 state[4];
    for (const string &pw : v)
    {
        MD5Hash(pw, state);
    }
#endif
}

static void HashBufferedGuesses(PriorityQueue &q)
{
    for (const auto &bucket : q.local_guesses)
    {
        HashVector(bucket);
    }
}

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);

    int rank = 0;
    int world_size = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    if (!CheckMD5Correctness(rank))
    {
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    double time_hash = 0;
    double time_train = 0;

    PriorityQueue q;

    streambuf *old_cout_buf = nullptr;
    ostringstream quiet_stream;
    if (rank != 0)
    {
        old_cout_buf = cout.rdbuf(quiet_stream.rdbuf());
    }

    double start_train = MPI_Wtime();
    q.m.train("/guessdata/Rockyou-singleLined-full.txt");
    q.m.order();
    double end_train = MPI_Wtime();
    time_train = end_train - start_train;

    if (rank != 0)
    {
        cout.rdbuf(old_cout_buf);
    }

    q.init();

    if (rank == 0)
    {
        cout << "here" << endl;
    }

    long long local_total_guesses = 0;
    long long global_history = 0;
    long long next_report = 100000;

    MPI_Barrier(MPI_COMM_WORLD);
    double start = MPI_Wtime();

    while (!q.priority.empty())
    {
        int actual_batch_size = (int)min((size_t)BATCH_SIZE, q.priority.size());
        vector<PT> batch_pts;
        batch_pts.reserve(actual_batch_size);

        for (int i = 0; i < actual_batch_size; i++)
        {
            batch_pts.emplace_back(q.priority[i]);
        }

        long long batch_global_count = 0;
        for (const PT &pt : batch_pts)
        {
            batch_global_count += CountPTCandidates(q, pt);
        }

        int before_local_buffer = q.total_guesses;
        for (int pt_idx = rank; pt_idx < actual_batch_size; pt_idx += world_size)
        {
            GeneratePTLocalOpenMP(q, batch_pts[pt_idx]);
        }

        int local_generated = q.total_guesses - before_local_buffer;
        local_total_guesses += local_generated;
        global_history += batch_global_count;

        AdvanceBatchQueue(q, batch_pts);

        if (rank == 0 && global_history >= next_report)
        {
            cout << "Guesses generated: " << global_history << endl;
            next_report = (global_history / 100000 + 1) * 100000;
        }

        if (q.total_guesses > 1000000 || global_history > GENERATE_LIMIT)
        {
            double start_hash = MPI_Wtime();
            HashBufferedGuesses(q);
            double end_hash = MPI_Wtime();
            time_hash += end_hash - start_hash;

            q.ClearGuesses();
        }

        if (global_history > GENERATE_LIMIT)
        {
            break;
        }
    }

    if (q.total_guesses > 0)
    {
        double start_hash = MPI_Wtime();
        HashBufferedGuesses(q);
        double end_hash = MPI_Wtime();
        time_hash += end_hash - start_hash;

        q.ClearGuesses();
    }

    double end = MPI_Wtime();
    double time_guess = (end - start) - time_hash;

    long long total_guesses = 0;
    double max_time_guess = 0;
    double max_time_hash = 0;
    double max_time_train = 0;

    MPI_Reduce(&local_total_guesses, &total_guesses, 1, MPI_LONG_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&time_guess, &max_time_guess, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&time_hash, &max_time_hash, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&time_train, &max_time_train, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        cout << "MPI processes:" << world_size << endl;
        cout << "OpenMP threads:" << GEN_THREADS << endl;
        cout << "Batch size:" << BATCH_SIZE << endl;
        cout << "Total guesses:" << total_guesses << endl;
        cout << "Guess time:" << max_time_guess << "seconds" << endl;
        cout << "Hash time:" << max_time_hash << "seconds" << endl;
        cout << "Train time:" << max_time_train << "seconds" << endl;
    }

    MPI_Finalize();
    return 0;
}
