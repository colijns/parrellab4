#include "PCFG.h"
#include "md5.h"
#include <mpi.h>
#include <array>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

#ifndef GENERATE_LIMIT
#define GENERATE_LIMIT 10000000
#endif

#ifndef USE_SIMD_HASH
#define USE_SIMD_HASH 1
#endif

static bool CheckMD5Correctness(int rank)
{
    if (rank == 0)
    {
        cout << "Testing MD5Hash correctness..." << endl;
    }

    string test_pws[8] = {"123456", "password", "12345678", "qwerty", "123456789", "12345", "1234", "111111"};
    string test_hashes[8] = {
        "e10adc3949ba59abbe56e057f20f883e",
        "5f4dcc3b5aa765d61d8327deb882cf99",
        "25d55ad283aa400af464c76d713c07ad",
        "d8578edf8458ce06fbc5bb76a58c5ca4",
        "25f9e794323b453885f5181f1b624d0b",
        "827ccb0eea8a706c4c34a16891f84e7b",
        "81dc9bdb52d04dc20036dbd8313ed055",
        "96e79218965eb72c92a549dd5a330112"
    };

    for (int i = 0; i < 8; i++)
    {
        bit32 state[4];
        MD5Hash(test_pws[i], state);

        stringstream ss;
        for (int j = 0; j < 4; j++)
        {
            ss << setw(8) << setfill('0') << hex << state[j];
        }

        if (ss.str() != test_hashes[i])
        {
            if (rank == 0)
            {
                cout << "MD5Hash test failed for " << test_pws[i] << "!" << endl;
                cout << "Expected: " << test_hashes[i] << "\nGot:      " << ss.str() << endl;
            }
            return false;
        }
    }

    if (rank == 0)
    {
        cout << "MD5Hash test passed!" << endl;
    }

    return true;
}

static void HashVector(const vector<string> &v)
{
    if (v.empty()) return;

#if USE_SIMD_HASH
    MD5HashBatchSIMD(v, nullptr);
#else
    bit32 state[4];
    for (const string &pw : v)
    {
        MD5Hash(pw, state);
    }
#endif
}

static void HashBufferedGuesses(PriorityQueue &q)
{
    HashVector(q.guesses);
}

static void PopNextMPI(PriorityQueue &q, int rank, int world_size, int &pt_global_count)
{
    pt_global_count = 0;
    if (q.priority.empty())
    {
        return;
    }

    q.Generate_mpi(q.priority.front(), rank, world_size, &pt_global_count);

    vector<PT> new_pts = q.priority.front().NewPTs();
    for (PT pt : new_pts)
    {
        q.CalProb(pt);
        for (auto iter = q.priority.begin(); iter != q.priority.end(); iter++)
        {
            if (iter != q.priority.end() - 1 && iter != q.priority.begin())
            {
                if (pt.prob <= iter->prob && pt.prob > (iter + 1)->prob)
                {
                    q.priority.emplace(iter + 1, pt);
                    break;
                }
            }
            if (iter == q.priority.end() - 1)
            {
                q.priority.emplace_back(pt);
                break;
            }
            if (iter == q.priority.begin() && iter->prob < pt.prob)
            {
                q.priority.emplace(iter, pt);
                break;
            }
        }
    }

    q.priority.erase(q.priority.begin());
}

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);

    int rank = 0;
    int world_size = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    if (!CheckMD5Correctness(rank))
    {
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    double time_hash = 0;
    double time_train = 0;

    PriorityQueue q;

    // Keep non-root ranks from interleaving identical training progress logs.
    streambuf *old_cout_buf = nullptr;
    ostringstream quiet_stream;
    if (rank != 0)
    {
        old_cout_buf = cout.rdbuf(quiet_stream.rdbuf());
    }

    double start_train = MPI_Wtime();
    q.m.train("/guessdata/Rockyou-singleLined-full.txt");
    q.m.order();
    double end_train = MPI_Wtime();
    time_train = end_train - start_train;

    if (rank != 0)
    {
        cout.rdbuf(old_cout_buf);
    }

    q.init();

    if (rank == 0)
    {
        cout << "here" << endl;
    }

    long long local_total_guesses = 0;
    long long global_history = 0;
    long long next_report = 100000;

    MPI_Barrier(MPI_COMM_WORLD);
    double start = MPI_Wtime();

    while (!q.priority.empty())
    {
        int pt_global_count = 0;
        int before_local_buffer = q.total_guesses;

        PopNextMPI(q, rank, world_size, pt_global_count);

        int local_generated = q.total_guesses - before_local_buffer;
        local_total_guesses += local_generated;
        global_history += pt_global_count;

        if (rank == 0 && global_history >= next_report)
        {
            cout << "Guesses generated: " << global_history << endl;
            next_report = (global_history / 100000 + 1) * 100000;
        }

        if (q.total_guesses > 1000000 || global_history > GENERATE_LIMIT)
        {
            double start_hash = MPI_Wtime();
            HashBufferedGuesses(q);
            double end_hash = MPI_Wtime();
            time_hash += end_hash - start_hash;

            q.ClearGuesses();
        }

        if (global_history > GENERATE_LIMIT)
        {
            break;
        }
    }

    if (q.total_guesses > 0)
    {
        double start_hash = MPI_Wtime();
        HashBufferedGuesses(q);
        double end_hash = MPI_Wtime();
        time_hash += end_hash - start_hash;

        q.ClearGuesses();
    }

    double end = MPI_Wtime();
    double time_guess = (end - start) - time_hash;

    long long total_guesses = 0;
    double max_time_guess = 0;
    double max_time_hash = 0;
    double max_time_train = 0;

    MPI_Reduce(&local_total_guesses, &total_guesses, 1, MPI_LONG_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&time_guess, &max_time_guess, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&time_hash, &max_time_hash, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&time_train, &max_time_train, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        cout << "Guess time:" << max_time_guess << "seconds" << endl;
        cout << "Hash time:" << max_time_hash << "seconds" << endl;
        cout << "Train time:" << max_time_train << "seconds" << endl;
        cout << "Total guesses:" << total_guesses << endl;
        cout << "MPI processes:" << world_size << endl;
    }

    MPI_Finalize();
    return 0;
}
